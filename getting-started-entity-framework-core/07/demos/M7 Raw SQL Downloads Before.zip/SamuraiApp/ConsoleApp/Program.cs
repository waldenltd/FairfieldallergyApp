﻿using SamuraiApp.Data;
using SamuraiApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ConsoleApp
{
  internal class Program
  {
    private static SamuraiContext _context = new SamuraiContext();

    private static void Main(string[] args)
    {
      
    }

 

  }
}