﻿namespace SamuraiApp.Domain
{
    public class Clan
    {
        public int Id { get; set; }
        public string ClanName { get; set; }
    }
}