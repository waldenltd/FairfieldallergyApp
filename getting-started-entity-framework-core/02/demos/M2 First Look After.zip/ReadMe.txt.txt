These are the before and after code for

Pluralsight.com
 Entity Framework Core: Getting Started (EF Core 3.1 update) by Julie Lerman
Created in Visual Studio 2019
Module 2: Creating Your First App Using EF Core 3.1
Before has 3 classes for you to copy/paste
After has the final solution of the module.