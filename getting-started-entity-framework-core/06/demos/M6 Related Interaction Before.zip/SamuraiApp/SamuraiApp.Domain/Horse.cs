﻿namespace SamuraiApp.Domain
{
  public class Horse
  {
    public int Id { get; set; }
    public string Name { get; set; }
    public int SamuraiId { get; set; }
  }
}
