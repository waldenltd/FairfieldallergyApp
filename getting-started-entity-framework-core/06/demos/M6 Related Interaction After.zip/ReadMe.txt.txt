These are the before and after solutions for
Pluralsight.com
 Entity Framework Core: Getting Started (EF Core 3.1 update) by Julie Lerman
Created in Visual Studio 2019
Module 6: Interacting with Related Data